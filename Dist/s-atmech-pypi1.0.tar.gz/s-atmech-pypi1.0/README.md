# s-atmech
With s-atmech you can implement attention mechanism (only supports Bahdanau Attention right now).
